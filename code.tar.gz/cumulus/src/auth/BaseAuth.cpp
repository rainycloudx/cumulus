//
// Created by Shantanu Banerjee on 09/10/23.
//

#include "BaseAuth.h"
#include "config.h"

#include <fstream>
#include <sstream>

namespace cumulus {

BaseAuth::BaseAuth() {

    std::stringstream stream;
    {
        std::ifstream config(constants::app_global::FIREBASE_SERVICE_JSON);
        stream << config.rdbuf();
    }

    firebase::AppOptions options;
    options.LoadFromJsonConfig(stream.str().c_str());

    app = firebase::App::Create(options);
    auth = firebase::auth::Auth::GetAuth(app);

}

BaseAuth::~BaseAuth() noexcept {
    if (auth) {
        delete auth;
        auth = nullptr;
    }

    if (app) {
        delete app;
        app = nullptr;
    }
}


}
