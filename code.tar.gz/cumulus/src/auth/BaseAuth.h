//
// Created by Shantanu Banerjee on 09/10/23.
//

#ifndef CUMULUS_BASEAUTH_H
#define CUMULUS_BASEAUTH_H

#include "firebase/app.h"
#include "firebase/auth.h"

namespace cumulus {

class BaseAuth {

public:
    BaseAuth();

    virtual ~BaseAuth();

    const firebase::App *getApp() const {
        return app;
    }

    const firebase::auth::Auth *getAuth() const {
        return auth;
    }

private:
    firebase::App*          app;
    firebase::auth::Auth*   auth;
};

}


#endif //CUMULUS_BASEAUTH_H
