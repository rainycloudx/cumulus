//
// Created by Shantanu Banerjee on 03/10/23.
//

#include "ClientThreadWorker.h"
#include "firebase/auth.h"
#include "firebase/app.h"

#include <algorithm>

namespace cumulus {

ClientThreadWorker::ClientThreadWorker(std::unique_ptr<connection::SSLSocket> socket)
        : _socket(std::move(socket)) {
    handle_client_handshake();
}

void ClientThreadWorker::handle_client_handshake() {
    char buf;
    _socket->receive(&buf, 1);
    if (buf == protocol::CONNECT_CMD) {

    }
}

}
